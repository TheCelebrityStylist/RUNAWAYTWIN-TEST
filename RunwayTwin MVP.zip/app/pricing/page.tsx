'use client';
import { useEffect, useState } from "react";
export default function Pricing(){
  const [state,setState]=useState<{userId:string;credits:number}>({userId:'',credits:0});
  useEffect(()=>{(async()=>{ const r=await fetch('/api/pay/credits').then(r=>r.json()); setState(r?.data || {userId:'',credits:0}); })();},[]);
  async function checkout(mode:"pay-per-look"|"bundle5"|"bundle10"|"bundle20"){
    const r=await fetch("/api/pay/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({ mode, userId: state.userId })}).then(r=>r.json());
    if(r?.data?.url) window.location.href=r.data.url;
  }
  return(<div className="max-w-2xl"><h1 className="text-3xl font-semibold mb-2">Pricing</h1><p className="opacity-70 mb-6">Credits on this device: <b>{state.credits}</b></p><div className="grid md:grid-cols-2 gap-6">
    <div className="bg-white rounded-xl p-6 shadow-soft"><h3 className="text-xl font-semibold">Single Look</h3><p className="opacity-80">€4.99 per generated look.</p><button className="mt-4 px-4 py-2 rounded-xl bg-brand text-white" onClick={()=>checkout("pay-per-look")}>Buy 1 Look</button></div>
    <div className="bg-white rounded-xl p-6 shadow-soft"><h3 className="text-xl font-semibold">5-Look Bundle</h3><p className="opacity-80">€14.99 for 5 looks.</p><button className="mt-4 px-4 py-2 rounded-xl bg-brand text-white" onClick={()=>checkout("bundle5")}>Buy 5</button></div>
    <div className="bg-white rounded-xl p-6 shadow-soft"><h3 className="text-xl font-semibold">10-Look Bundle</h3><p className="opacity-80">€24.99 for 10 looks.</p><button className="mt-4 px-4 py-2 rounded-xl bg-brand text-white" onClick={()=>checkout("bundle10")}>Buy 10</button></div>
    <div className="bg-white rounded-xl p-6 shadow-soft"><h3 className="text-xl font-semibold">20-Look Bundle</h3><p className="opacity-80">€39.99 for 20 looks.</p><button className="mt-4 px-4 py-2 rounded-xl bg-brand text-white" onClick={()=>checkout("bundle20")}>Buy 20</button></div>
  </div></div>);
}
