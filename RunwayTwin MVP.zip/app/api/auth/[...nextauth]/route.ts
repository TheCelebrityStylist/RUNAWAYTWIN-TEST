import NextAuth, { NextAuthOptions } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import EmailProvider from "next-auth/providers/email";
export const runtime="nodejs";
export const authOptions: NextAuthOptions = {
  providers:[
    Credentials({ name:"Dev Login", credentials:{ email:{ label:"Email", type:"text" } }, async authorize(c){ const email=(c?.email||'').toString(); if(!email) return null; return { id: email, email }; } }),
    ...(process.env.EMAIL_SERVER ? [EmailProvider({ server: process.env.EMAIL_SERVER, from: process.env.EMAIL_FROM||"RunwayTwin <no-reply@runwaytwin.example>" })] : [])
  ],
  session:{ strategy:"jwt" }
};
const handler = NextAuth(authOptions); export { handler as GET, handler as POST };
