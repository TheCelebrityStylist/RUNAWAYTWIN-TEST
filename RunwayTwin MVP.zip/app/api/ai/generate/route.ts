import { NextRequest, NextResponse } from "next/server";
import { StyleBrief, ApiResponse } from "@/lib/schemas";
import { planOutfits } from "@/lib/ai/planner";
import { countLooks, incLooks, getOrCreateUserId } from "@/lib/cookies";
import { isPaid } from "@/lib/paywall";
import { getCredits, consumeCredit } from "@/lib/credits";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parse = StyleBrief.safeParse(body);
    if (!parse.success) return NextResponse.json({ ok: false, error: parse.error.message } satisfies ApiResponse, { status: 400 });
    const looks = await countLooks(); const paid = isPaid(); const userId = await getOrCreateUserId(); const credits = await getCredits(userId);
    if (!paid && credits <= 0 && looks >= 1) return NextResponse.json({ ok: false, error: "Free look used. Please purchase or use credits." } satisfies ApiResponse, { status: 402 });
    if (!paid && credits > 0 && looks >= 1) { const ok = await consumeCredit(userId); if (!ok) return NextResponse.json({ ok: false, error: "Not enough credits." } satisfies ApiResponse, { status: 402 }); }
    const result = await planOutfits(parse.data); await incLooks();
    return NextResponse.json({ ok: true, data: result } satisfies ApiResponse, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "Unknown error" } satisfies ApiResponse, { status: 500 });
  }
}
