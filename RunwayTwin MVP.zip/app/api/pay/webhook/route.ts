import { NextRequest, NextResponse } from "next/server";
import { addCredits } from "@/lib/credits";
import { headers } from "next/headers";
export const runtime = "nodejs";
export async function POST(req: NextRequest) {
  const sig = headers().get("stripe-signature");
  const whsec = process.env.STRIPE_WEBHOOK_SECRET;
  const body = await req.text();
  if (!process.env.STRIPE_SECRET_KEY || !sig || !whsec) { await addCredits("guest_mock", 5); return NextResponse.json({ ok: true, mock: true }); }
  try {
    const Stripe = (await import("stripe")).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });
    const event = stripe.webhooks.constructEvent(body, sig, whsec);
    if (event.type === "checkout.session.completed") {
      const s: any = event.data.object;
      const userId = (s.client_reference_id || s.customer_email || "guest").toString();
      const credits = parseInt((s.metadata?.credits || "1"), 10);
      await addCredits(userId, credits);
    }
    return NextResponse.json({ ok: true });
  } catch (e: any) { return NextResponse.json({ ok: false, error: e?.message || "Webhook error" }, { status: 400 }); }
}
