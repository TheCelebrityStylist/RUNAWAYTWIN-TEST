import { NextRequest, NextResponse } from "next/server";
import { getOrCreateUserId } from "@/lib/cookies";
export const runtime = "nodejs";
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const mode = String(body.mode || "pay-per-look");
    const userId = String(body.userId || await getOrCreateUserId());
    if (!process.env.STRIPE_SECRET_KEY) return NextResponse.json({ ok: true, data: { url: "/pay/success?mock=1" } });
    const Stripe = (await import("stripe")).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });
    const price = (mode==='pay-per-look'?499: mode==='bundle5'?1499: mode==='bundle10'?2499: 3999);
    const credits = (mode==='pay-per-look'?1: mode==='bundle5'?5: mode==='bundle10'?10:20);
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{ price_data: { currency:"eur", product_data:{ name:"RunwayTwin Credits" }, unit_amount: price }, quantity:1 }],
      metadata: { credits: credits.toString(), userId },
      client_reference_id: userId,
      success_url: `${process.env.NEXTAUTH_URL || "http://localhost:3000"}/pay/success`,
      cancel_url: `${process.env.NEXTAUTH_URL || "http://localhost:3000"}/pay/cancel`,
    });
    return NextResponse.json({ ok: true, data: { url: session.url } });
  } catch (e: any) { return NextResponse.json({ ok: false, error: e?.message || "Payment error" }, { status: 500 }); }
}
