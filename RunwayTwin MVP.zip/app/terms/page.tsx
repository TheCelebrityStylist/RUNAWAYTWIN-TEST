export default function Terms(){return(<div className='prose max-w-3xl'><h1>Terms & Conditions</h1><p>Non-advisory fashion guidance; affiliate relationships may exist.</p></div>);}
