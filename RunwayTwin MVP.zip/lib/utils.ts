export function nowIso(){return new Date().toISOString();} export function clsx(...v:(string|false|undefined|null)[]){return v.filter(Boolean).join(' ');}
