export const SYSTEM_PROMPT=`You are RunwayTwin... JSON only ...`;
